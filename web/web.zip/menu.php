<!DOCTYPE html>
<html>
<head>
<title>BorkStore A Ecommerce Category Flat Bootstrap Responsive Website Template | Inicio :: w3layouts</title>
<link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700italic' rel='stylesheet' type='text/css'>

<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="keywords" content="BorkStore Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Slab:300,700,400' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
<!--//fonts-->
<!-- start menu -->
<link href="css/megamenu.css" rel="stylesheet" type="text/css" media="all" />
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script type="text/javascript" src="js/megamenu.js"></script>
<script>$(document).ready(function(){$(".megamenu").megamenu();});</script>
<!--//slider-script-->

<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
		    <script type="text/javascript">
			    $(document).ready(function () {
			        $('#horizontalTab').easyResponsiveTabs({
			            type: 'default', //Types: default, vertical, accordion           
			            width: 'auto', //auto or any width like 600px
			            fit: true   // 100% fit in a container
			        });
			    });
				
</script>	

<script src="js/simpleCart.min.js"> </script>

</head>
<body> 
<!--header-->	
<div class="header">
	<div class="header-top">
		<div class="container">
			<!--<div class="header-top-in">
				
				<ul class="support">
					<li ><a href="mailto:info@example.com" ><i > </i>info@example.com</a></li>
					<li ><span ><i class="tele-in"> </i>0 462 261 61 61</span></li>			
				</ul>
				<ul class=" support-right">
					<li ><a href="account.php" ><i class="men"> </i>Login</a></li>
					<li ><a href="account.php" ><i class="tele"> </i>Registrate</a></li>			
				</ul>
				<div class="clearfix"> </div>
			</div>-->
			</div>
            <div class="container">			
				<div class="logo">
					<h1><a href="index.php">BorkStore</a></h1>
				</div>
			<div class="header-bottom">
			
				<div class="top-nav">
				<!-- start header menu -->
		<ul class="megamenu skyblue">
			<li><a  href="index.php">Inicio</a></li>
			
			<li class="active grid"><a  href="#">Menu</a>
				<div class="megapanel">
					<div class="row">
						<div class="col1">
							<div class="h_nav">
								<h4>SUBMENU1</h4>
								<ul>
									<li><a href="about.php">About</a></li>
									<li><a href="product.php">men</a></li>
									<li><a href="product.php">women</a></li>
									<li><a href="product.php">accessories</a></li>
									
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>SUBMENU2</h4>
								<ul>
									<li><a href="product.php">trends</a></li>
									<li><a href="product.php">sale</a></li>
									<li><a href="product.php">style videos</a></li>
									<li><a href="product.php">accessories</a></li>
									<li><a href="product.php">kids</a></li>
									<li><a href="product.php">style videos</a></li>
								</ul>	
							</div>							
						</div>
						<div class="col1 col5">
							<iframe src="https://player.vimeo.com/video/10777111?color=ffffff&title=0&byline=0&portrait=0"  webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe> 
						</div>
						
					</div>
					
    				</div>
				</li>	
		<li ><a  href="404.php">Blog</a></li>				
				<li><a  href="#">Productos</a>
				<div class="megapanel">
					<div class="row">
						<div class=" col-nav">
							<div class="h_nav">
								<h4>BEST SELLING</h4>
								<div class="sell">
									<div class="men">
										<a href="product.php"><img src="images/pi.jpg" alt="" ></a>
									</div>
									<div class="men-in">
										<h6>Lorem Ipsum</h6>
										<span>$.60.00</span>
									</div>
									<div class="clearfix"> </div>
								</div>	
								<div class="sell">
									<div class="men">
										<a href="product.php"><img src="images/pi11.jpg" alt="" ></a>
									</div>
									<div class="men-in">
										<h6> Dummy Text</h6>
										<span>$.160.00</span>
									</div>
									<div class="clearfix"> </div>
								</div>	
								<div class="sell">
									<div class="men">
										<a href="product.php"><img src="images/pi12.jpg" alt="" ></a>
									</div>
									<div class="men-in">
										<h6>Standard Chunk</h6>
										<span>$.80.00</span>
									</div>
									<div class="clearfix"> </div>
								</div>	
							</div>							
						</div>
						<div class=" col-nav">
							<div class="h_nav">
								<h4>TOP RATE</h4>
								<div class="sell">
									<div class="men">
									<a href="product.php"><img src="images/pi13.jpg" alt="" ></a>
									</div>
									<div class="men-in">
										<h6> Perspiciatis Und</h6>
										<span>$.90.00</span>
									</div>
									<div class="clearfix"> </div>
								</div>	
								<div class="sell">
									<div class="men">
										<a href="product.php"><img src="images/pi.jpg" alt="" ></a>
									</div>
									<div class="men-in">
										<h6>Veritatis Et</h6>
										<span>$.60.00</span>
									</div>
									<div class="clearfix"> </div>
								</div>	
								<div class="sell">
									<div class="men">
										<a href="product.php"><img src="images/pi11.jpg" alt="" ></a>
									</div>
									<div class="men-in">
										<h6>Lorem Ipsum</h6>
										<span>$.100.00</span>
									</div>
									<div class="clearfix"> </div>
								</div>	
							</div>							
						</div>
					</div>
    				</div>
				</li>
				
				<li><a  href="Contacto.php">Contacto</a>
					
				</li>
		 </ul> 
		 <!---->
		 <div class="search-in" >
			<div class="search" >
						<form>
							<input type="text" value="Keywords" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Keywords';}" class="text">
							<input type="submit" value="SEARCH">
						</form>
							<div class="close-in"><img src="images/close.png" alt="" /></div>
					</div>
			<div class="right"><button> </button></div>
				</div>
						<script type="text/javascript">
							$('.search').hide();
							$('button').click(function (){
							$('.search').show();
							$('.text').focus();
							}
							);
							$('.close-in').click(function(){
							$('.search').hide();
							});
						</script>

					<!---->
					<div class="cart box_1">
						<a href="checkout.php">
						<h3> <div class="total">
							<span class="simpleCart_total"></span> (<span id="simpleCart_quantity" class="simpleCart_quantity"></span> items)</div>
							<img src="images/cart.png" alt=""/></h3>
						</a>
						<p><a href="javascript:;" class="simpleCart_empty">Vaciar Carro</a></p>
						<div class="clearfix"> </div>
					</div>

<div class="clearfix"> </div>
					<!---->
				</div>
				
			</div>
			<div class="clearfix"> </div>
		</div>
		</div>